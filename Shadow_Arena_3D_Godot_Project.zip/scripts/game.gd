extends Node3D

var player: CharacterBody3D
var enemy: CharacterBody3D
var camera_rig: Node3D
var info_label: Label

func _ready() -> void:
    player = get_node("Player")
    enemy = get_node("Enemy")
    camera_rig = get_node("CameraRig")
    info_label = get_node("UI/HUD/Info")

func _process(_delta: float) -> void:
    if is_instance_valid(player):
        camera_rig.global_position = player.global_position + Vector3(0, 2.8, 0)
        var camera: Camera3D = camera_rig.get_node("Camera3D")
        camera.look_at(player.global_position + Vector3(0, 1.0, -2.0), Vector3.UP)
        info_label.text = "SHADOW ARENA 3D  |  HP: %d  |  MUSUH: %d" % [player.health, enemy.health]
