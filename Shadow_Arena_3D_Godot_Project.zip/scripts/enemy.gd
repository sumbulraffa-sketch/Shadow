extends CharacterBody3D

@export var max_health: int = 100
var health: int = 100
var attack_timer: float = 0.0
var player: CharacterBody3D

func _ready() -> void:
    health = max_health
    player = get_tree().current_scene.get_node("Player")
    _make_enemy()

func _physics_process(delta: float) -> void:
    if not is_instance_valid(player):
        return
    attack_timer = maxf(0.0, attack_timer - delta)
    var offset := player.global_position - global_position
    offset.y = 0
    var distance := offset.length()
    if distance > 1.55:
        var dir := offset.normalized()
        velocity.x = dir.x * 2.0
        velocity.z = dir.z * 2.0
        look_at(global_position + dir, Vector3.UP)
    else:
        velocity.x = 0
        velocity.z = 0
        if attack_timer <= 0.0:
            attack_timer = 1.3
            player.take_damage(8)
    velocity.y -= 20.0 * delta
    move_and_slide()
    global_position.x = clampf(global_position.x, -10.0, 10.0)
    global_position.z = clampf(global_position.z, -10.0, 10.0)

func take_damage(amount: int) -> void:
    health = maxi(0, health - amount)
    if health <= 0:
        health = max_health
        global_position = Vector3(randf_range(-6, 6), 0, randf_range(-6, -3))

func _make_enemy() -> void:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.85, 0.12, 0.22)
    var torso := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.45
    capsule.height = 1.55
    torso.mesh = capsule
    torso.position.y = 1.0
    torso.material_override = mat
    add_child(torso)
    var head := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.29
    sphere.height = 0.58
    head.mesh = sphere
    head.position.y = 1.98
    head.material_override = mat
    add_child(head)
