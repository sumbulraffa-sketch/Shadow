extends CharacterBody3D

@export var move_speed: float = 5.0
@export var max_health: int = 100
var health: int = 100
var attack_cooldown: float = 0.0
var attack_requested: bool = false
var mobile_direction: Vector2 = Vector2.ZERO

func _ready() -> void:
    health = max_health
    _make_character(Color(0.08, 0.45, 0.95))
    var hud = get_tree().current_scene.get_node("UI/HUD")
    hud.get_node("AttackButton").pressed.connect(_request_attack)
    hud.get_node("UpButton").button_down.connect(func(): mobile_direction.y = -1)
    hud.get_node("UpButton").button_up.connect(func(): if mobile_direction.y < 0: mobile_direction.y = 0)
    hud.get_node("DownButton").button_down.connect(func(): mobile_direction.y = 1)
    hud.get_node("DownButton").button_up.connect(func(): if mobile_direction.y > 0: mobile_direction.y = 0)
    hud.get_node("LeftButton").button_down.connect(func(): mobile_direction.x = -1)
    hud.get_node("LeftButton").button_up.connect(func(): if mobile_direction.x < 0: mobile_direction.x = 0)
    hud.get_node("RightButton").button_down.connect(func(): mobile_direction.x = 1)
    hud.get_node("RightButton").button_up.connect(func(): if mobile_direction.x > 0: mobile_direction.x = 0)

func _request_attack() -> void:
    attack_requested = true

func _physics_process(delta: float) -> void:
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    var input_dir := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
    if mobile_direction.length() > 0.1:
        input_dir = mobile_direction
    var direction := Vector3(input_dir.x, 0, input_dir.y).normalized()
    velocity.x = direction.x * move_speed
    velocity.z = direction.z * move_speed
    velocity.y -= 20.0 * delta
    move_and_slide()
    if direction.length() > 0.1:
        look_at(global_position + direction, Vector3.UP)
    if Input.is_key_pressed(KEY_SPACE):
        if not _space_was_down:
            attack_requested = true
        _space_was_down = true
    else:
        _space_was_down = false
    if attack_requested:
        attack_requested = false
        _attack()
    global_position.x = clampf(global_position.x, -10.0, 10.0)
    global_position.z = clampf(global_position.z, -10.0, 10.0)

var _space_was_down := false

func _attack() -> void:
    if attack_cooldown > 0.0:
        return
    attack_cooldown = 0.55
    var enemy = get_tree().current_scene.get_node_or_null("Enemy")
    if enemy and global_position.distance_to(enemy.global_position) < 2.7:
        enemy.take_damage(20)

func take_damage(amount: int) -> void:
    health = maxi(0, health - amount)
    if health == 0:
        health = max_health
        global_position = Vector3(0, 0, 4)

func _make_character(color: Color) -> void:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    var torso := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.42
    capsule.height = 1.5
    torso.mesh = capsule
    torso.position.y = 1.0
    torso.material_override = mat
    add_child(torso)
    var head := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.28
    sphere.height = 0.56
    head.mesh = sphere
    head.position.y = 1.95
    head.material_override = mat
    add_child(head)
    var blade := MeshInstance3D.new()
    var blade_mesh := BoxMesh.new()
    blade_mesh.size = Vector3(0.08, 0.8, 0.12)
    blade.mesh = blade_mesh
    blade.position = Vector3(0.48, 1.15, -0.12)
    blade.rotation_degrees.z = -20
    var steel := StandardMaterial3D.new()
    steel.albedo_color = Color(0.75, 0.9, 1.0)
    blade.material_override = steel
    add_child(blade)
