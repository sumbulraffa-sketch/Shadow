SHADOW ARENA 3D — PROYEK GODOT

Ini adalah PROYEK SUMBER, bukan APK yang sudah dibangun.

Fitur prototipe:
- Arena 3D ringan dan offline.
- Karakter pemain biru dan lawan merah dibuat dari bentuk 3D sederhana.
- Kamera orang ketiga mengikuti pemain.
- Musuh mengejar dan menyerang otomatis.
- Tombol layar untuk bergerak dan menyerang.
- Menyerang mengurangi HP musuh jika cukup dekat.

Cara memakai:
1. Ekstrak ZIP ke folder di Redmi Pad SE.
2. Buka proyek project.godot dengan Godot Editor untuk Android (Godot 4.x).
3. Tekan Run Project untuk mencoba.
4. Untuk APK: siapkan dukungan ekspor Android sesuai dokumentasi resmi Godot dan versi editor. Jika editor Android di tablet tidak menyediakan ekspor APK, proyek perlu diekspor melalui lingkungan build yang mendukung Android.

Kontrol:
- Tombol panah layar untuk bergerak.
- Tombol SERANG untuk menyerang.
- Pada keyboard: tombol panah/WASD untuk bergerak dan SPACE untuk menyerang.

Catatan:
- Prototipe belum memakai model ninja animasi, suara, atau efek jurus.
- Ukuran APK akhir bergantung pada Godot, template ekspor, arsitektur, dan aset. Tidak bisa dijamin ukuran tertentu sebelum build.
